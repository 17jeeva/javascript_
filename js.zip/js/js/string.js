document.getElementById("btn").addEventListener("click",()=>{
let a=document.getElementById("t1").value
// document.getElementById("dv").innerHTML = a.toUpperCase()
// document.getElementById("dv").innerHTML = a.toLowerCase()
// document.getElementById("dv").innerHTML = a.to()
// document.getElementById("dv").innerHTML = a.trim()
})