let arr = [
    {fullName:"Amir",designation:"Developer",company:"Why Global Services",salary:"5000"},
    {fullName:"Siva",designation:"Tester",company:"Tech mahindra",salary:"10000"},
    {fullName:"karthick",designation:"Marketing Associate",company:"TCS",salary:"15000"},
    {fullName:"Hussain",designation:"HR",company:"Wipro",salary:"20000"},
]
console.log(arr)