let emptyArray=[];
console.log(emptyArray)