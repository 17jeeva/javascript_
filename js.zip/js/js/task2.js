document.getElementById("student1").addEventListener('click',()=>{
    document.getElementById("dv").innerHTML = `<br>Full Name : Abigail<br>D.O.B : 15-09-1997<br>Department : B.Sc. Computer Science`
})
document.getElementById("student2").addEventListener('click',()=>{
    document.getElementById("dv").innerHTML = `<br>Full Name : Adah<br>D.O.B : 04-10-1999<br>Department : B.Sc. Psychology`
})
document.getElementById("student3").addEventListener('click',()=>{
    document.getElementById("dv").innerHTML = `<br>Full Name : Anna<br>D.O.B : 08-09-2001<br>Department : B.Sc. Computer Science`
})